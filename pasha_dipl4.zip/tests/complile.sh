solc ../smartcontracts/utils/*.sol ../smartcontracts/nft/*.sol --optimize --optimize-runs 200  --combined-json abi,bin > ../smartcontracts/compiled/contracts.json

