contract address: 0x47446783032C47Be68036ED3A4AcbB271c428Daf, GOERLI
OPENSEA: https://testnets.opensea.io/collection/nftpass-fphjm9wkl3
API URL: https://nft-auth-api.id-chain.net

