solc --abi ./nft/nft.sol -o abi/nftpass
